package com.example.guneetsinghlamba.sgnparking;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SMS extends AppCompatActivity implements  View.OnClickListener {


    Button button1;
    Button button2;
    Button button3;
    Button button4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);
        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);
        button4 = (Button) findViewById(R.id.button4);
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
    }
    private void sendSMS1(){
        Intent smsIntent = new Intent(Intent.ACTION_SENDTO,
                Uri.parse("smsto:6476857191"));
        smsIntent.putExtra("sms_body", "Test message");

        if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.SEND_SMS) !=
                PackageManager.PERMISSION_GRANTED){
            Toast.makeText(getApplicationContext(),
                    "SMS permission denied",Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(smsIntent);
    }
    private void sendSMS2(){
        Intent smsIntent = new Intent(Intent.ACTION_SENDTO,
                Uri.parse("smsto:6476857191"));
        smsIntent.putExtra("sms_body", "Test message");

        if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.SEND_SMS) !=
                PackageManager.PERMISSION_GRANTED){
            Toast.makeText(getApplicationContext(),
                    "SMS permission denied",Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(smsIntent);
    }
    private void sendSMS3(){
        Intent smsIntent = new Intent(Intent.ACTION_SENDTO,
                Uri.parse("smsto:6476857191"));
        smsIntent.putExtra("sms_body", "Test message");

        if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.SEND_SMS) !=
                PackageManager.PERMISSION_GRANTED){
            Toast.makeText(getApplicationContext(),
                    "SMS permission denied",Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(smsIntent);
    }
    private void sendEmail(){
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("text/plain");

        emailIntent.putExtra(Intent.EXTRA_EMAIL,
                new String[]{"singhguneet311@gmail..com"});

        emailIntent.putExtra(Intent.EXTRA_SUBJECT,
                "Test Email");
        emailIntent.putExtra(Intent.EXTRA_TEXT,
                "This is a test message");

        emailIntent.setType("message/rfc822");

        startActivity(Intent.createChooser(emailIntent,
                "Select Email Client"));
    }
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.button1:
                sendSMS1();
                break;
            case R.id.button2:
               sendSMS2();
                break;
            case R.id.button3:
                sendSMS3();
                break;
            case R.id.button4:
                sendEmail();
                break;
        }

    }

}
