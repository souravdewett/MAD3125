package com.example.guneetsinghlamba.sgnparking;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class ParkingManual extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parking_manual);
        WebView webManual = (WebView) findViewById(R.id.web);
        webManual.loadUrl("file:///android_asset/Parking_Manual.html");
    }
}
