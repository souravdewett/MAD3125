package com.example.guneetsinghlamba.sgnparking;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class feedAdpater extends BaseAdapter {


    Context context;

    ArrayList<String> feedsub;
    ArrayList<String> feedmessage;



    feedAdpater(Context context3, ArrayList<String> subject, ArrayList<String> message) {
       this.context = context3;
        this.feedsub = subject;
        this.feedmessage = message;
    }


    @Override
    public int getCount() {
        return feedsub.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        feedData feedData;
        LayoutInflater layoutInflater;
        if(view == null) {
            layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            view = layoutInflater.inflate(R.layout.custom_home,null);
            feedData = new feedData();
            feedData.Subject = (TextView) view.findViewById(R.id.feedsubject);
            feedData.Message = (TextView) view.findViewById(R.id.feedmessage);
            view.setTag(feedData);
        }
        else {
            feedData = (feedData) view.getTag();
        }
        feedData.Subject.setText("# "+feedsub.get(i));
        feedData.Message.setText(feedmessage.get(i));
        return  view;
    }
    public  class feedData {
        TextView Subject;
        TextView Message;

    }

}
