package com.example.macstudent.day1androidapplicationprogramming;

import android.content.Context;
import android.content.Intent;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.*;
import android.content.Intent.*;

public class launcher extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);

        final Context context;
        context = this;

        Thread timer = new Thread() {
            public void run() {
                try {
                    sleep(3000);
                }catch(Exception ex) {
                    Log.e("Launcher","Thread wait failed"); // print error message.
                }
                finally {
                    Intent loginIntent = new Intent(context,LoginActivity.class);
                    startActivity(loginIntent);

                }
            }
        };
timer.start();
    }
}
